#!/bin/zsh
cd -- "$(dirname -- "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Installa Python 3.9+ da https://www.python.org/downloads/'
else
  python3 menu.py
fi
printf '\nPremi INVIO per uscire... '
read
