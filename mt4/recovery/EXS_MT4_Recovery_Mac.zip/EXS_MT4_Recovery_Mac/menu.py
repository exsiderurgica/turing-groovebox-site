#!/usr/bin/env python3
"""EXS MT4 / FM-1 Recovery Kit 1.0 — guided front-end for pinned MIT tools.
The kit never flashes without a user-selected action and upstream confirmation.
"""
from __future__ import annotations
import hashlib
import io
import os
from pathlib import Path
import platform
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / "engine"
REVISION = "517b9387e62e908115e5eec66c32d0ac3289f039"
URL = "https://codeload.github.com/Quixotic7/MvaveFM1Unbricker/zip/" + REVISION
BLOBS = {
    "fm1_unbrick.py": "e42154a51c7bbacc25a7270279b6d7929c3c2fbf",
    "fm1_transporter_recover.py": "7ea6fa21bac5e78ec8fb43973aceed339f4db12a",
    "LICENSE": "cad75a98fa03068bb8ef5579867a0eeb84c497d1",
    "transporter/fm1_transporter-a632d92-placeholder.uf2": "ef33d4f943a92060653b64a9ed66b49636b9d68f",
    "transporter/placeholder_loader.pattern": "e289526a2c3be1f03248e14a5aae9bf79727d4fd",
}
ALLOW = {"fm1_unbrick.py", "fm1_transporter_recover.py", "README.md",
         "UNBRICK-GUIDE.md", "TRANSPORTER-GUIDE.md", "LICENSE", "requirements.txt"}
IS_WIN = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"

def git_sha1(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def pause():
    input("\nPremi INVIO per tornare al menu... ")

def install_engine():
    if (ENGINE / "fm1_unbrick.py").is_file() and (ENGINE / "fm1_transporter_recover.py").is_file():
        for key, want in BLOBS.items():
            p = ENGINE / key
            if not p.exists() or git_sha1(p.read_bytes()) != want:
                raise RuntimeError("I file del motore non corrispondono alla versione verificata: " + key)
        print("Motore gia' scaricato e verificato.")
        return
    print("Download strumenti open-source MIT da GitHub, versione bloccata:", REVISION[:12])
    print("Serve Internet. Non viene scaricato alcun firmware M-VAVE.")
    with urllib.request.urlopen(urllib.request.Request(URL, headers={"User-Agent": "EXS-MT4-Recovery/1.0"}), timeout=60) as resp:
        payload = resp.read(15_000_000)
    if len(payload) >= 15_000_000:
        raise RuntimeError("Archivio troppo grande: download rifiutato")
    selected = {}
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            bits = info.filename.split("/", 1)
            if len(bits) != 2:
                continue
            rel = bits[1]
            if rel in ALLOW or (rel.startswith("transporter/") and
                                 rel in {"transporter/README.md", "transporter/xiao-wiring.svg", *[k for k in BLOBS if k.startswith("transporter/")]}):
                selected[rel] = archive.read(info)
    for name, sha in BLOBS.items():
        if name not in selected or git_sha1(selected[name]) != sha:
            raise RuntimeError("Verifica integrita' fallita per " + name + "; nessun file installato")
    for name, data in selected.items():
        target = ENGINE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print("Motore pronto. I file originali e la licenza MIT sono in 'engine'.")

def run(script, *args):
    install_engine()
    cmd = [sys.executable, str(ENGINE / script), *args]
    print("\nComando:", " ".join(str(x) for x in cmd), "\n")
    completed = subprocess.run(cmd, cwd=ENGINE, check=False)
    print("\nCodice finale:", completed.returncode)
    if completed.returncode == 3:
        print("ATTENZIONE: verifica scrittura FALLITA. NON spegnere/scollegare la FM1; segui il messaggio del tool.")

def setup():
    install_engine()
    if IS_WIN:
        run("fm1_unbrick.py", "setup")
    elif IS_MAC:
        print("Mac: preparo i componenti per il percorso XIAO RP2040.")
        run("fm1_transporter_recover.py", "setup")
    else:
        print("Per questa versione del kit usare Windows o macOS.")

def windows_scan():
    print("Ricerca dei dispositivi USB/UBOOT, sola lettura.")
    subprocess.run(["powershell.exe", "-NoProfile", "-Command",
                    "Get-CimInstance Win32_DiskDrive | Select-Object Index,Model,InterfaceType | Format-Table -AutoSize; "
                    "Get-PnpDevice | Where-Object { $_.InstanceId -like '*VID_4C4A*' } | Select-Object Status,Class,FriendlyName | Format-Table -AutoSize"], check=False)
    print("Se compare WL82 UBOOT1.00: NON formattare l'unita'.")
    print("Se non compare: prova un cavo DATI, porta diretta e alimentazione stabile.")

def mac_scan():
    print("Diagnosi USB macOS, sola lettura. Mac NON supporta il recupero SCSI diretto.")
    subprocess.run(["system_profiler", "SPUSBDataType", "-detailLevel", "mini"], check=False)
    print("Cerca FM-1, WL82, UBOOT o Vendor ID 0x4c4a.")
    print("Se trovi WL82, passa a un PC Windows/Linux; Mac NON puo' fare il restore diretto.")
    print("Se non e' visibile alcun dispositivo, consulta la guida Transporter XIAO RP2040.")

def is_admin():
    if not IS_WIN:
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False

def windows_write_guard():
    if not is_admin():
        print("E' necessario avviare AVVIA_WINDOWS.cmd come AMMINISTRATORE (tasto destro).")
        return False
    return True

def official_package():
    candidates = [ROOT / "FM-1.fwsc", ENGINE / "FM-1.fwsc"]
    for path in candidates:
        if path.is_file():
            return path
    print("Manca FM-1.fwsc (firmware originale V15): scaricalo da https://www.m-vave.com/download")
    print("Mettilo accanto a AVVIA_WINDOWS.cmd o AVVIA_MAC.command, senza rinominarlo.")
    print("Il tool verifica il contenuto PRIMA di scrivere. Non usare file MT4 al suo posto.")
    return None

def backup():
    if not windows_write_guard():
        return
    import datetime
    path = ENGINE / "backups" / ("manuale-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    run("fm1_unbrick.py", "backup", str(path))
    print("Non pubblicare il backup: puo' contenere patch, suoni e dati personali.")

def restore():
    if not windows_write_guard():
        return
    fw = official_package()
    if fw is None:
        return
    print("\nRECUPERO FIRMWARE ORIGINALE V15: procedura potenzialmente rischiosa.")
    print("Non scollegare durante il flash. Il tool eseguira' prima backup doppio e verifica hash.")
    print("Se non rileva esattamente un WL82 con chip e memoria attesi, si ferma.")
    if input("Per continuare digita V15: ").strip() != "V15":
        print("Annullato.")
        return
    run("fm1_unbrick.py", "restore", str(fw), "--verify-v15")
    print("Solo se il tool indica completamento verificato, scollega, spegni, attendi 5 secondi, riaccendi.")

def mac_softkey():
    print("SOLO se FM1 ancora funzionante e presente come USB MIDI.")
    print("Questo comando puo' entrare in UBOOT ma NON ripristina il firmware da Mac.")
    if input("Digita MIDI per continuare: ").strip() != "MIDI":
        return
    run("fm1_unbrick.py", "softkey")

def mac_transporter():
    print("SERVE un Seeed XIAO RP2040, cavo dati USB-C, pigtail USB-C e cablaggio sicuro.")
    print("NON collegare VBUS/filo rosso. Leggi prima engine/TRANSPORTER-GUIDE.md e lo schema.")
    print("NON usare RP2350; controlla i pin con cura. Il tool richiede WRITE prima della scrittura.")
    fw = official_package()
    if fw is None:
        return
    if input("Hai letto la guida e collegato tutto correttamente? Digita XIAO: ").strip() != "XIAO":
        return
    run("fm1_transporter_recover.py", "wizard", "--v15", str(fw))

def main():
    if sys.version_info < (3, 9):
        raise SystemExit("Serve Python 3.9 o successivo. Scarica da https://www.python.org/downloads/")
    if not (IS_WIN or IS_MAC):
        raise SystemExit("Questo kit e' per Windows e macOS. Per Linux consulta il progetto originale.")
    print("EXSIDERURGICA / EXS MT4 / FM1 RECOVERY KIT 1.0")
    print("NON ufficiale. Nessun flash automatico. Internet necessario per scaricare strumenti.")
    while True:
        print("\nSISTEMA:", platform.platform())
        print("1 - DIAGNOSI USB (non scrive nulla)")
        print("2 - SCARICA/PREPARA strumenti verificati (Python + Internet)")
        if IS_WIN:
            print("3 - CONTROLLA CHIP UBOOT (richiede setup e amministratore)")
            print("4 - BACKUP completo FM1 (richiede UBOOT + amministratore)")
            print("5 - RECUPERA firmware originale V15 (richiede UBOOT + amministratore)")
        else:
            print("3 - USB-MIDI: forza UBOOT su FM1 FUNZIONANTE (non ripara da Mac)")
            print("4 - SETUP Transporter XIAO RP2040 (hardware aggiuntivo)")
            print("5 - WIZARD RECUPERO con Transporter XIAO RP2040")
        print("0 - ESCI")
        choice = input("Selezione: ").strip()
        if choice == "0":
            break
        try:
            if choice == "1":
                windows_scan() if IS_WIN else mac_scan()
            elif choice == "2":
                setup()
            elif choice == "3":
                run("fm1_unbrick.py", "info") if IS_WIN else mac_softkey()
            elif choice == "4":
                backup() if IS_WIN else run("fm1_transporter_recover.py", "setup")
            elif choice == "5":
                restore() if IS_WIN else mac_transporter()
            else:
                print("Scelta non valida.")
        except (OSError, RuntimeError, urllib.error.URLError, zipfile.BadZipFile) as exc:
            print("ERRORE: ", exc)
            print("Se il download/setup fallisce, verifica rete, Python e permessi; niente flash senza backup.")
        except KeyboardInterrupt:
            print("\nInterrotto.")
        pause()

if __name__ == "__main__":
    main()
