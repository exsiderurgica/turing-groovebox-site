@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 menu.py
) else (
  python menu.py
)
if errorlevel 1 echo Installare Python 3.9+ da https://www.python.org/downloads/ e riprovare.
echo.
pause
